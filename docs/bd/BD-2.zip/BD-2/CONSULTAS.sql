-- ================================================= CONSULTAS SQL =================================================
-- ################### JUN��O INTERNA ###################
-- Consulta que devolve o nome dos cursos e o nome das respetivas categorias
SELECT c.NOME_CURSO, cat.NOME_CAT AS CATEGORIA
FROM CURSOS c INNER JOIN CATEGORIA cat 
	ON c.ID_CATEGORIA = cat.ID_CATEGORIA;
-- Consulta que mostra o nome do curso, categoria, �rea e t�pico correspondente
SELECT 
    c.NOME_CURSO,
    cat.NOME_CAT AS CATEGORIA,
    a.NOME_AREA AS AREA,
    t.NOME_TOPICO AS TOPICO
FROM CURSOS c INNER JOIN CATEGORIA cat 
	ON c.ID_CATEGORIA = cat.ID_CATEGORIA
INNER JOIN AREA a 
	ON c.ID_AREA = a.ID_AREA
INNER JOIN TOPICO t 
	ON c.ID_TOPICO = t.ID_TOPICO;


--################### JUN��O EXTERNA ################### 
-- Consulta que devolve todos os cursos sicronos e os nomes dos formadores que os lecionam.
SELECT CURSOS.NOME_CURSO, FORMADORES.NOME_UTILIZADOR AS FORMADOR
FROM CURSOS RIGHT OUTER JOIN SINCRONO 
	ON CURSOS.ID_CURSO = SINCRONO.ID_CURSO 
LEFT JOIN FORMADORES 
		ON SINCRONO.ID_FORMADOR = FORMADORES.ID_FORMADOR;
--################### UNI�O ################### 
-- Consulta que devolve os nomes dos cursos s�ncronos e ass�ncronos
SELECT NOME_CURSO
FROM SINCRONO
UNION
SELECT NOME_CURSO
FROM ASSINCRONO;


----################### AGRUPAMENTO C/ HAVING --###################
-- Consulta que mostra os cursos com mais de 2 inscri��es
SELECT CURSOS.NOME_CURSO, COUNT(INSCRICOES.ID_INSCRICAO) AS NUM_INSCRITOS
FROM CURSOS JOIN INSCRICOES 
	ON CURSOS.ID_CURSO = INSCRICOES.ID_CURSO
GROUP BY CURSOS.NOME_CURSO
HAVING COUNT(INSCRICOES.ID_INSCRICAO) > 2;

-- --################### FUN�OES DE AGREGA��O --###################
-- M�dia de resultados obtidos por cada curso s�ncrono
SELECT s.NOME_CURSO, AVG(r.RESUL) AS media_resultados
FROM RESULTADOS JOIN SINCRONO s 
	ON r.ID_CURSO_SINCRONO = s.ID_CURSO_SINCRONO
GROUP BY s.NOME_CURSO;
-- Curso com o maior n�mero de formandos
SELECT NOME_CURSO, CONTADOR_FORMANDOS
FROM CURSOS
WHERE CONTADOR_FORMANDOS = (
    SELECT MAX(CONTADOR_FORMANDOS) FROM CURSOS
);


-- ###################  SUBCONSULTAS ###################
--Com cl�usula Where
-- Consulta que devolve os cursos que t�m inscri��es feitas por um formando com email 'formando@example.com'
SELECT NOME_CURSO
FROM CURSOS
WHERE ID_CURSO IN (
    SELECT ID_CURSO
    FROM INSCRICOES
    WHERE ID_FORMANDO IN (
        SELECT ID_FORMANDO
        FROM FORMANDOS
        WHERE EMAIL = 'joao.silva@email.pt'
    )
);
-- Consulta que devolve os cursos que pertencem a uma determinada �rea e que t�m mais de 'X' formandos
SELECT c.NOME_CURSO, c.CONTADOR_FORMANDOS, a.NOME_AREA
FROM CURSOS c
JOIN AREA a ON c.ID_AREA = a.ID_AREA
WHERE a.NOME_AREA = 'Frontend' AND c.CONTADOR_FORMANDOS > 1;
--Com cl�usula Having
-- Consulta que devolve os cursos com formandos acima da m�dia por categoria
SELECT 
	f.NOME_UTILIZADOR,
    c.NOME_CURSO,
	AVG(r.RESUL)AS RESULTADO
FROM FORMANDOS f INNER JOIN RESULTADOS r
	ON f.ID_FORMANDO = r.ID_FORMANDO
INNER JOIN CURSOS c
	ON c.ID_CURSO = r.ID_CURSO
GROUP BY f.NOME_UTILIZADOR, c.NOME_CURSO
HAVING AVG(r.RESUL) > (
        SELECT AVG(res.RESUL)
        FROM CURSOS c INNER JOIN RESULTADOS res
			ON c.ID_CURSO = res.ID_CURSO
);