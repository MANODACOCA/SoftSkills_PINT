
-- ================================================= OBJETOS L�GICOS =================================================
-- ################### PROCEDIMENTOS ARMAZENADOS ###################
-- Procedimento Armazenado para inserir um novo curso
-- Este procedimento recebe os dados do curso (nome, categoria, �rea, t�pico) e insere um novo curso na tabela CURSOS.
CREATE PROCEDURE inserir_curso
    @p_id_topico INT,
    @p_id_utilizador INT,
    @p_id_gestor_administrador INT,
    @p_id_categoria INT,
    @p_id_area INT,
    @p_nome_curso VARCHAR(255),
    @p_descricao_curso VARCHAR(MAX),
    @p_numero_vagas INT,
    @p_data_inicio DATETIME,
    @p_data_fim DATETIME,
    @p_tipo_curso INT,
	@estado INT,
    @p_idioma VARCHAR(50),
    @p_horas_curso FLOAT,
    @p_contador_formandos INT,
    @p_imagem VARCHAR(50)  -- ou VARCHAR(MAX) se for um caminho ou URL
AS
BEGIN
    INSERT INTO CURSOS (
        ID_TOPICO, 
        ID_UTILIZADOR,
        ID_GESTOR_ADMINISTRADOR,
        ID_CATEGORIA,
        ID_AREA,
        NOME_CURSO, 
        DESCRICAO_CURSO, 
        NUMERO_VAGAS, 
        DATA_INICIO_CURSO,
        DATA_FIM_CURSO,
        TIPO_CURSO,
		ESTADO,
        IDIOMA, 
        HORAS_CURSO, 
        CONTADOR_FORMANDOS,
        IMAGEM
    ) 
    VALUES (
        @p_id_topico,
        @p_id_utilizador,
        @p_id_gestor_administrador,
        @p_id_categoria,
        @p_id_area,
        @p_nome_curso,
        @p_descricao_curso,
        @p_numero_vagas,
        @p_data_inicio,
        @p_data_fim,
        @p_tipo_curso,
		@estado,
        @p_idioma,
        @p_horas_curso,
        @p_contador_formandos,
        @p_imagem
    );
END;
GO

EXEC inserir_curso
    @p_id_topico = 3,
    @p_id_utilizador = 2,
    @p_id_gestor_administrador = 2,
    @p_id_categoria = 1,
    @p_id_area = 2,
    @p_nome_curso = 'Curso de SQL Server',
    @p_descricao_curso = 'Curso intensivo de SQL Server',
    @p_numero_vagas = 20,
    @p_data_inicio = '2025-06-01 09:00:00',
    @p_data_fim = '2025-06-30 18:00:00',
    @p_tipo_curso = 2,
	@estado = 1,
    @p_idioma = 'Portugu�s',
    @p_horas_curso = 40.5,
    @p_contador_formandos = 0,
    @p_imagem = 'react.png';
SELECT *FROM CURSOS

-- ################### FUN��ES ###################
-- Fun��o para contar o n�mero total de cursos de uma determinada �rea
-- Recebe o ID da �rea e devolve a quantidade de cursos dessa �rea.
CREATE FUNCTION contar_cursos_por_area (@p_nome_area VARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @v_total INT;

    SELECT @v_total = COUNT(*)
    FROM CURSOS c INNER  JOIN AREA a
		ON c.ID_AREA = a.ID_AREA
    WHERE a.NOME_AREA = @p_nome_area;

    RETURN @v_total;
END;

SELECT sc24_36.contar_cursos_por_area('Frontend') AS total_cursos;

-- ################### TRIGGERS ###################
-- Trigger para registar uma ocorr�ncia ao inserir um novo curso
-- Esta trigger insere um registo na tabela OCORRENCIAS_EDICOES sempre que um novo curso for inserido.

CREATE TRIGGER trg_registar_ocorrencia_inserir_curso
ON CURSOS
AFTER INSERT
AS
BEGIN
    INSERT INTO OCORRENCIAS_EDICOES (NR_OCORRENCIA,ID_CURSO)
    SELECT 11, ID_CURSO
    FROM INSERTED;
END;

EXEC inserir_curso/*Utilizei o procedimento para inserir novo curso para testar o trigger(contar_cursos_por_area)*/
    @p_id_topico = 3,
    @p_id_utilizador = 2,
    @p_id_gestor_administrador = 2,
    @p_id_categoria = 1,
    @p_id_area = 2,
    @p_nome_curso = 'Curso de SQL Server',
    @p_descricao_curso = 'Curso intensivo de SQL Server',
    @p_numero_vagas = 20,
    @p_data_inicio = '2025-06-01 09:00:00',
    @p_data_fim = '2025-06-30 18:00:00',
    @p_tipo_curso = 2,
	@estado = 1,
    @p_idioma = 'Portugu�s',
    @p_horas_curso = 40.5,
    @p_contador_formandos = 0,
    @p_imagem = 'react.png';
SELECT *FROM CURSOS
SELECT *FROM OCORRENCIAS_EDICOES/*aqui vizualizo os resultados inseridos pelo trigger*/


-- Trigger para atualizar o contador de formandos quando uma inscri��o � realizada
-- Esta trigger atualiza o campo CONTADOR_FORMANDOS na tabela CURSOS sempre que uma nova inscri��o for feita.
CREATE TRIGGER trg_atualizar_contador_formandos
ON INSCRICOES
AFTER INSERT
AS
BEGIN
    -- Atualiza o contador de formandos para cada curso relacionado �s inscri��es inseridas
    UPDATE C
    SET C.CONTADOR_FORMANDOS += I.TotalInscricoes
    FROM CURSOS C
    INNER JOIN (
        SELECT ID_CURSO, COUNT(*) AS TotalInscricoes
        FROM INSERTED
        GROUP BY ID_CURSO
    ) I ON C.ID_CURSO = I.ID_CURSO;
END;

INSERT INTO INSCRICOES
VALUES(1, 1, 1, '2024-07-15 22:59:59.000', '2024-07-16 22:59:59.000', 1)
/*aqui vizualizo os resultados inseridos pelo trigger*/
SELECT *FROM INSCRICOES
SELECT *FROM CURSOS
-- ################### CURSORES ###################
-- Cursor para iterar sobre os cursos e seus formandos
-- Este cursor seleciona todos os cursos e os formandos associados, imprimindo seus valores.
DECLARE @v_nome_curso VARCHAR(255);
DECLARE @v_contador_formandos INT;

DECLARE curso_cursor CURSOR FOR
    SELECT NOME_CURSO, CONTADOR_FORMANDOS
    FROM CURSOS;

OPEN curso_cursor;

FETCH NEXT FROM curso_cursor INTO @v_nome_curso, @v_contador_formandos;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Exibir os dados
    PRINT 'Curso: ' + @v_nome_curso + ', Formandos a participar: ' + CAST(@v_contador_formandos AS VARCHAR);

    FETCH NEXT FROM curso_cursor INTO @v_nome_curso, @v_contador_formandos;
END;

CLOSE curso_cursor;
DEALLOCATE curso_cursor;